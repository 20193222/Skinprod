package com.example.pod;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class cart_adapter extends RecyclerView.Adapter<cart_adapter.MyViewHolder> {

    private Context context;
    private Activity activity;
    private ArrayList prod_name, prod_price, prod_cat;

    cart_adapter(Activity activity, Context context,  ArrayList prod_name, ArrayList prod_price, ArrayList prod_cat){
        this.activity = activity;
        this.context = context;
        this.prod_name = prod_name;
        this.prod_price = prod_price;
        this.prod_cat = prod_cat;
    }


    @Override
    public cart_adapter.MyViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.row_list, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(cart_adapter.MyViewHolder holder, int position) {
        holder.prd_name.setText(String.valueOf(prod_name.get(position)));
        holder.prod_cat.setText(String.valueOf(prod_cat.get(position)));
        holder.prod_price.setText(String.valueOf(prod_price.get(position)));
    }

    @Override
    public int getItemCount() {
        return prod_name.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView prd_name, prod_cat, prod_price;

        public MyViewHolder(View itemView) {
            super(itemView);
            prd_name = itemView.findViewById(R.id.productnamecart);
            prod_cat = itemView.findViewById(R.id.productcat);
            prod_price = itemView.findViewById(R.id.productpricecat);

        }
    }
}
