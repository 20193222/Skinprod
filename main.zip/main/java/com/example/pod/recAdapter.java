package com.example.pod;

import android.annotation.SuppressLint;
import android.text.InputFilter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class recAdapter extends RecyclerView.Adapter<recAdapter.recViewHolder> {

    private ArrayList<product_list> product_lists, product_lists2, cart_list;
    private RecViewClickListener listener;



    public recAdapter(ArrayList<product_list> product_lists,  RecViewClickListener listener){
        this.product_lists = product_lists;
        this.product_lists2 = product_lists;

        this.listener = listener;
    }

    public void setTaskMode(ArrayList<product_list> cart_list){
        this.cart_list = cart_list;
        notifyDataSetChanged();
    }

    public class recViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        ImageView image;
        TextView productname, productcat;

        public recViewHolder(final View view, View view2){
            super(view);
            image = view.findViewById(R.id.productimg);
            productname = view.findViewById(R.id.productname);
            productcat = view.findViewById(R.id.productcat);

            view.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            listener.onClick(view, getAdapterPosition());

        }
    }

    @NonNull
    @Override
    public recAdapter.recViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_list, parent, false);
        View itemView2 = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_category_product_list, parent, false);
        return new recViewHolder(itemView, itemView2);
    }


    @Override
    public void onBindViewHolder(@NonNull recAdapter.recViewHolder holder, int position) {
        int image = product_lists.get(position).getImage();
        String productname = product_lists.get(position).getProductname();
        String productdesc = product_lists.get(position).getProductdesc();
        String price = product_lists.get(position).getPrice();
        String productcat = product_lists.get(position).getProductcat();

        holder.image.setImageResource(image);
        holder.productname.setText(productname);
        holder.productcat.setText(productcat);

    }

    @Override
    public int getItemCount() {
        return product_lists.size();
    }

    public interface RecViewClickListener{
        void onClick(View view, int position);
    }
}
