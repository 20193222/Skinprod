package com.example.pod;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class category extends AppCompatActivity implements View.OnClickListener {
    public CardView cat1, cat2, cat3, cat4, cat5, cat6, cat7;


    private ImageView homebtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        cat1 =  findViewById(R.id.cat1);
        cat2 =  findViewById(R.id.cat2);
        cat3 =  findViewById(R.id.cat3);
        cat4 =  findViewById(R.id.cat4);
        cat5 =  findViewById(R.id.cat5);
        cat6 =  findViewById(R.id.cat6);
        cat7 =  findViewById(R.id.cat7);

        cat1.setOnClickListener(this);
        cat2.setOnClickListener(this);
        cat3.setOnClickListener(this);
        cat4.setOnClickListener(this);
        cat5.setOnClickListener(this);
        cat6.setOnClickListener(this);
        cat7.setOnClickListener(this);


        homebtn = findViewById(R.id.homebtn);

        homebtn.setOnClickListener(this);
    }






    @Override
    public void onClick(View v) {
        Intent intent, intent1;

        switch (v.getId()){
            case R.id.homebtn:
                intent = new Intent(this,MainActivity.class);
                startActivity(intent);
                break;
            case R.id.cat1:
                intent = new Intent(this,category_product_list.class);
                startActivity(intent);
                break;
            case R.id.cat2:
                intent = new Intent(this,category_product_list.class);
                startActivity(intent);
                break;
            case R.id.cat3:
                intent = new Intent(this,category_product_list.class);
                startActivity(intent);
                break;
            case R.id.cat4:
                intent = new Intent(this,category_product_list.class);
                startActivity(intent);
                break;
            case R.id.cat5:
                intent = new Intent(this,category_product_list.class);
                startActivity(intent);
                break;
            case R.id.cat6:
                intent = new Intent(this,category_product_list.class);
                startActivity(intent);
                break;
            case R.id.cat7:
                intent = new Intent(this,category_product_list.class);
                startActivity(intent);
                break;
        }
    }
}