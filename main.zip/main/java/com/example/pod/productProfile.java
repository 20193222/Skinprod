package com.example.pod;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collections;

public class productProfile extends AppCompatActivity implements View.OnClickListener {


    public ImageView backbtn;
    private Button add;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.product_details);



        ImageView productImage = findViewById(R.id.detailImage);
        TextView productName = findViewById(R.id.detailname);
        TextView productDesc = findViewById(R.id.detaildesc);
        TextView productPrice = findViewById(R.id.detailprice);
        TextView productCat = findViewById(R.id.detailcat);
        TextView productTotal = findViewById(R.id.total);

        add = findViewById(R.id.addtocart);

        String prodname = "Product name not set";
        String proddesc = "Product description not set";
        String prodprice = "Product Price not set";
        String prodcat = "Product Category not set";
        int prodimage = 1;


        Bundle extras = getIntent().getExtras();
        if (extras!= null){
            prodname = extras.getString("Product Name");
            proddesc = extras.getString("Product Desc");
            prodprice = extras.getString("Product Price");
            prodimage = extras.getInt("Product Image");
            prodcat = extras.getString("Product Cat");


        }

        productName.setText(prodname);
        productDesc.setText(proddesc);
        productPrice.setText(prodprice);
        productCat.setText(prodcat);
        productImage.setImageResource(prodimage);

        int finalProdimage = prodimage;
        String finalProdname = prodname;
        String finalProddesc = proddesc;
        int finalProdprice = Integer.valueOf(prodprice);

        int total1, total2, finaltotal;
        String finalProdcat = prodcat;

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDataHelper myDb = new MyDataHelper(productProfile.this);
                myDb.addtoCart(finalProdname, finalProddesc, finalProdprice, finalProdcat);





            }

         });
    }




    @Override
    public void onClick(View v) {
        Intent intent;

        switch (v.getId()){

        }

    }
}
