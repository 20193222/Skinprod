package com.example.pod;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    public CardView cardcategory, cardproducts, cardcart;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cardcategory =  findViewById(R.id.category);
        cardproducts =  findViewById(R.id.products);
        cardcart =  findViewById(R.id.cart);


        cardcategory.setOnClickListener(this);
        cardproducts.setOnClickListener(this);
        cardcart.setOnClickListener(this);



    }

    @Override
    public void onClick(View v) {
        Intent intent;

        switch (v.getId()){
            case R.id.category:
                intent = new Intent(this,category.class);
                startActivity(intent);
                break;
            case R.id.products:
                intent = new Intent(this,products.class);
                startActivity(intent);
                break;
            case R.id.cart:
                intent = new Intent(this,carts.class);
                startActivity(intent);
                break;
        }

    }
}