package com.example.pod;

import java.io.Serializable;

public class product_list implements Serializable {
    int image;
    String productname, productdesc, productcat, price;

    public product_list(int image, String productname,String productdesc, String price, String productcat){
        this.image = image;
        this.productname = productname;
        this.productdesc = productdesc;
        this.price = price;
        this.productcat = productcat;
    }

    public int getImage(){
        return image;
    }

    public String getProductname(){
        return productname;
    }

    public String getProductdesc(){
        return productdesc;
    }

    public String getProductcat(){
        return productcat;
    }

    public String getPrice(){
        return price;
    }

    public void setProductname(String productname){
        this.productname = productname;
    }

    public void setProductdesc(String productdesc){
        this.productdesc = productdesc;
    }

    public void setProductcat(String productcat){
        this.productcat = productcat;
    }

    public void setPrice(String price){
        this.price = price;
    }

    public void setImage(int image){
        this.image = image;
    }

}
