package com.example.pod;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class carts extends AppCompatActivity implements View.OnClickListener {
    private RecyclerView recyclerView;
    private ImageView homebtn;
    private Button delete;

    MyDataHelper myDB;
    private ArrayList<String>  prod_name, prod_price, prod_cat;
    TextView total, no_data, texttots, textr;
    cart_adapter adapter;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carts);

        total = findViewById(R.id.total);
        no_data = findViewById(R.id.nodata);
        texttots = findViewById(R.id.texttots);
        textr = findViewById(R.id.textt);



        recyclerView = findViewById(R.id.recviewcart);
        myDB = new MyDataHelper(carts.this);
        prod_name = new ArrayList<>();
        prod_price = new ArrayList<>();
        prod_cat = new ArrayList<>();

        storeDataInArrays();

        adapter = new cart_adapter(carts.this, this, prod_name, prod_price, prod_cat);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(carts.this));

        int sum = myDB.countAllData();
        total.setText(Integer.toString(sum));


        homebtn = findViewById(R.id.homebtn);

        homebtn.setOnClickListener(this);


        delete = findViewById(R.id.delete);
        delete.setOnClickListener(this);
    }

    void storeDataInArrays(){
        Cursor cursor = myDB.readAllData();
        if(cursor.getCount() == 0){
            no_data.setVisibility(View.VISIBLE);

        }else{
            while (cursor.moveToNext()){
                prod_name.add(cursor.getString(0));
                prod_price.add(cursor.getString(2));
                prod_cat.add(cursor.getString(1));
            }
            no_data.setVisibility(View.GONE);
        }
    }

    void confirmDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete All?");
        builder.setMessage("Are you sure you want to delete all Data?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                MyDataHelper myDB = new MyDataHelper(carts.this);
                myDB.deleteAllData();
                //Refresh Activity
                Intent intent = new Intent(carts.this, carts.class);
                startActivity(intent);
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }

    @Override
    public void onClick(View v) {
        Intent intent;

        switch (v.getId()){
            case R.id.homebtn:
                intent = new Intent(this,MainActivity.class);
                startActivity(intent);
                break;
            case R.id.delete:
                confirmDialog();
                break;
        }
    }
}